package developers.yong.resvView;

import javafx.scene.Parent;

public interface ResvViewService {
	public void resvView(Parent root, String memId);
}
