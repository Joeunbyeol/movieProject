package developers.soo.service;

import javafx.scene.Parent;

public interface Login {
	public void setRoot(Parent root);
	public void login();
	
}
