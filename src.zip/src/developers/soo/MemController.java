package developers.soo;

import javafx.scene.Parent;

public class MemController {
	Parent root;
	public void setRoot(Parent root) {this.root=root;}
	public void onSave(){}
}
